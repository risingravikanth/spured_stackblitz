export class serviceOrder{
    summary:any;
    labourCost:number;
    partCost:number;
    constructor(){
        this.summary = "";
        this.labourCost = 0 ;
        this.partCost  = 0;
    }
  }