export interface ResponseData {
    successResponse: any,
    failedResponse: any
}